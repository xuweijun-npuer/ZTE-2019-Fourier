clc
clear
load data5 trainx
load data6 trainz
n=length(trainx);
x_abs=abs(trainx);
z_abs=abs(trainz);
%K�ǽ״Σ�M�Ǽ������
for K=1:20
    for M=0:20
         U=[];
        for i=1:M+1
            for j=1:K
                U=[U trainx(M+2-i:n-i+1,:).*(x_abs(M-i+2:n-i+1,:).^(j-1))];
            end
        end
        y=trainz(M+1:n,:);
        Uh=U';
        B=(Uh*U\Uh)*y;%(b10,b20....bk0,b11,b21...bkq)
        Z=U*B;
        
        %��ָ��
        fenmu=sum(z_abs(M+1:n).^2);
        fenzi=sum((abs(trainz(M+1:n)-Z)).^2);
        NMSE(K,M+1)=10*log10(fenzi/fenmu);
    end
end
surf(NMSE)