clc
clear
load pa_in_out_memoryless pa_in_memoryless
load pa_in_out_memoryless pa_out_memoryless
pa_in_abs=abs(pa_in_memoryless);
x1=pa_in_memoryless;
x2=x1.*pa_in_abs;%�������˻�
x3=x2.*pa_in_abs;
I=[x1.';x2.';x3.'];
I=I.';
poly3=inv(I'*I)*I'*pa_out_memoryless;
pa_out_simulate=I*poly3;
scatter(abs(pa_in_memoryless),abs(pa_out_memoryless),'b');
hold on
scatter(abs(pa_in_memoryless),abs(pa_out_simulate),'r');
sum1=0;
sum2=0;
for i=1:1:1000
sum1=sum1+(abs(pa_out_simulate(i)-pa_out_memoryless(i))).^2;
sum2=sum2+(abs(pa_out_memoryless(i))).^2;
NMSE=10*log10(sum1/sum2);
end
